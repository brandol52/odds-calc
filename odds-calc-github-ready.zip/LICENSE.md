MIT License

Copyright (c) 2025 Bryan Randol