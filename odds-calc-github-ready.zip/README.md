# Odds Calc

A PWA odds calculator.